Please complete your work in the Jupyter Notebook
